import mysql.connector
coding='utf-8'
import urllib2
import re 
import codecs 
import os
conn=mysql.connector.connect(host='localhost',database='praneet',user='root',password='hello')
if conn.is_connected() :
	print 'connected to database'
else :
	print 'error connecting to databse'

def insert_info(info):
	query="INSERT INTO eattreat(id,article,author,datte,tags,content)" \
			"VALUES(%s,%s,%s,%s,%s,%s)"
	cursor=conn.cursor()
	cursor.executemany(query,info)
	conn.commit()
	cursor.close()
	conn.close()
info=[]
for k in range(52) :
	if k > 0:
		eattreat="http://eattreat.in/page/"+str(k+1)+"/?s&submit"
	else :
		eattreat= "http://eattreat.in"
	page= urllib2.urlopen(eattreat)
	from bs4 import BeautifulSoup
	soup= BeautifulSoup(page,"html.parser")#.encode("utf-8")
#print soup.prettify()
#print soup
	allheads= soup.find_all("h2")
	alpha = []
	beta=[]
	for heads in allheads :
		alpha.append(heads)

	print type(alpha) 
	for j in alpha :
		print str(j)
		alllinks=re.findall('http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', str(j))
		beta.append(alllinks[0])


	print alpha
	print beta
	gama= []
	gama1=[]
	heads=[]
	auuthor=[]
	tags=[]
	tags1=[]
	datte=[]
	lo=[]
	for i in range(len(beta)) :

		source= beta[i]
		pages= urllib2.urlopen(source)
		soup=BeautifulSoup(pages,"html.parser")
		allparas= soup.find_all("p")
		allhead= soup.find_all("h1")
		alltags=soup.find_all("a",rel='tag')
		allauthor=soup.find_all("a",rel='author')
		alldates=soup.find_all("a",class_='meta-author-date')
		for paras in allparas :
			gama.append(paras.string)
		for teg in alltags :
			tags.append(teg.string)
		auuthor.append(allauthor[0].string)
		heads.append(allhead[0].string)	
		tags1.append(teg)
		gama1.append(gama)
		for dates in alldates:
			dates=str(dates)
			go=dates.split(">")
			for g in go:
				g=g.replace('\t','')
				g=g.replace('\xc2','')
				g=g.replace('\xa0','')
				g=g.replace('/','')
				g=g.replace('<div','')
				lo.append(g)
		if not lo[3]:
			lo[3]='no date'
		datte.append(lo[3])
		print ('the date is')
		print datte
	for j in range(len(heads)) :
		heads[j] = heads[j].replace('\t','') 
		heads[j] = heads[j].replace('\n','') 
		heads[j] = heads[j].replace('\r','')
		heads[j] = heads[j].replace('\u2019','')  
		heads[j] = heads[j].replace('|','')  

		heads[j] = heads[j].replace(':','') 
		heads[j] = heads[j].replace('!','') 
		heads[j] = heads[j].replace('@','') 
		heads[j] = heads[j].replace('#','')
		heads[j] = heads[j].replace('$','')
		heads[j] = heads[j].replace('%','')
		heads[j] = heads[j].replace('^','') 
		heads[j] = heads[j].replace('&','') 
		heads[j] = heads[j].replace('*','') 
		heads[j] = heads[j].replace('(','') 
		heads[j] = heads[j].replace(')','') 
		heads[j] = heads[j].replace('_','') 
		heads[j] = heads[j].replace('-','') 
		heads[j] = heads[j].replace('=','') 
		heads[j] = heads[j].replace('+','') 
		heads[j] = heads[j].replace('[','') 
		heads[j] = heads[j].replace(']','') 
		heads[j] = heads[j].replace('{','') 
		heads[j] = heads[j].replace('}','') 
		heads[j] = heads[j].replace(';','') 
		heads[j] = heads[j].replace("'",'')
		heads[j] = heads[j].replace('<','') 
		heads[j] = heads[j].replace('>','') 
		heads[j] = heads[j].replace(',','')
		heads[j] = heads[j].replace('.','') 
		heads[j] = heads[j].replace('?','') 
		heads[j] = heads[j].replace('/','')  
		heads[j] = heads[j].encode('utf-8') 

		print "this is heading"
		print heads[j]
		info.append([j,heads[j],auuthor[j],datte[j],tags1[j],gama1[j]])

print type(info)
insert_info(info)