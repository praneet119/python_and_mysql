# encoding=utf-8
import mysql.connector
coding='utf-8'
import urllib2
import re 
import codecs 
import os
conn=mysql.connector.connect(host='localhost',database='praneet',user='root',password='hello')
if conn.is_connected() :
	print 'connected to database'
else :
	print 'error connecting to databse'

def insert_info(info):
	query="INSERT INTO eattreat(id,article,author,datte,tags,content)" \
			"VALUES(%s,%s,%s,%s,%s,%s)"
	cursor=conn.cursor()
	cursor.executemany(query,info)
	conn.commit()
	cursor.close()
	conn.close()
	
info=[]


for k in range(32) :
	eattreat="http://eattreat.in/page/"+str(k+1)
	page= urllib2.urlopen(eattreat)
	from bs4 import BeautifulSoup
	soup= BeautifulSoup(page,"html.parser")
	allheads= soup.find_all("h1")
	alpha = []
	beta=[]
	for header in allheads :
		alpha.append(header) 
	for j in alpha :
		alllinks=re.findall('http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', str(j))
		beta.append(alllinks[0])
	lo=[]
	for i in range(len(beta)) :
		tags=[]
		gama=[]
		source= beta[i]
		pages= urllib2.urlopen(source)
		soup=BeautifulSoup(pages,"html.parser")
		allparas= soup.find_all("p")
		allhead= soup.find_all("h1")
		alltags=soup.find_all("a",rel='tag')
		allauthor=soup.find_all("a",rel='author')
		alllinks= soup.find_all("div",class_='meta-author-date')
		for link in alllinks :
			#print link
			link=str(link)
			#print type(link)
			go=link.split(">")
		for g in go:
			g=g.replace('\t','')
			g=g.replace('\xc2','')
			g=g.replace('\xa0','')
			g=g.replace('/','')
			g=g.replace('<div','')
			lo.append(g)
	#go.encode("utf-8")
		#print('the dat is')
		#print lo[3]
		for paras in allparas :
			gama.append(paras.string)
		for teg in alltags :
			tags.append(teg.string)
		if not allauthor:
			allauthor='no author'
			auuthor=allauthor[0]
		else:
			auuthor.append(allauthor[0].string)
		if not allhead:
			allhead='no heading'
			heads.append(allhead[0])
		else:	
			heads.append(allhead[0].string)	
#		print ('the tags for this article are')
#		print tags
		tags1.append(tags)
#		print tags1
		#print('the tags are')
		#print tags1
		gama1.append(gama)
		
		#if not lo[3]:
		#	lo[3]='no date'
		#datte.append(lo[3])
		datte.append(lo[3])

	for j in range(len(beta)) :
		string = heads[j]
		string = string.replace('\t','') 
		string = string.replace('\n','') 
		string = string.replace('\r','')
#		string = string.replace('\u2019','')  
		string = string.replace('|','')  

		string = string.replace(':','') 
		string = string.replace('!','') 
		string = string.replace('@','') 
		string = string.replace('#','') 
		string = string.replace('$','')
		string = string.replace('%','')
		string = string.replace('^','') 
		string = string.replace('&','') 
		string = string.replace('*','') 
		string = string.replace('(','') 
		string = string.replace(')','') 
		string = string.replace('_','') 
		string = string.replace('-','') 
		string = string.replace('=','') 
		string = string.replace('+','') 
		string = string.replace('[','') 
		string = string.replace(']','') 
		string = string.replace('{','') 
		string = string.replace('}','') 
		string = string.replace(';','') 
		string = string.replace("'",'')
		string = string.replace('<','') 
		string = string.replace('>','') 
		string = string.replace(',','')
		string = string.replace('.','') 
		string = string.replace('?','') 
		string = string.replace('/','')
		heads[j] = string
#		heads[j] = heads[j].decode().encode('utf-8','ignore')
		print heads[j]#.decode().encode('utf-8','ignore')
#			print heads[j].encode('utf-8')

		#print "this is heading"
		#print heads[j]
'''
		print ('now all the info')
		print ('the id is')
		print j
		print ('the heading is')
		print heads[j]
		print ('the author is')
		print auuthor[j]
		print ('the date is')
		print datte[j]
		print ('the tags are')
		print tags1[j]
		info.append([j,heads[j],auuthor[j],datte[j],tags1[j],gama1[j]])
'''
#print type(info)
insert_info(info)